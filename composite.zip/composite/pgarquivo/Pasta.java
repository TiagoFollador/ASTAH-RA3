
package composite.pgarquivo;

import composite.modelo.Composicao;

public class Pasta extends Composicao {
    
    public Pasta(String nm){
        super(nm);
    }    
}
